package com.customer.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.exceptions.CustomerNotFound;
import com.customer.models.Customer;
import com.customer.dao.CustomerDao;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao cusDao;

	@Override
	public boolean createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		cusDao.save(customer);
		return true;
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub

		cusDao.save(customer);
		return true;
	}

	@Override
	public boolean deleteCustomer(int cusId) throws CustomerNotFound {
		// TODO Auto-generated method stub
		Optional<Customer> optional = cusDao.findById(cusId);
		if (optional.isPresent()) {
			cusDao.deleteById(cusId);
			return true;
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}
	}

	@Override
	public Customer getCustomerById(int cusId)  {
		// TODO Auto-generated method stub
		Optional<Customer> optional = cusDao.findById(cusId);
		return optional.get();
		
	}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return cusDao.findAll();
	}

}
