package com.transaction.exceptions;

public class TransactionNotFound extends Exception {
	public TransactionNotFound(String message) {
		super(message);
	}
}
