package com.transaction.services;

import java.util.List;

import com.transaction.models.Transaction;

public interface TransactionService {
	public abstract boolean createTransaction(Transaction transaction);

	public abstract boolean updateTransaction(Transaction transaction);

	public abstract boolean deleteTransaction(int tranId);

	public abstract Transaction getTransaction(int tranId);

	public abstract List<Transaction> getAllTransactionByAccNumber(long accNumber);

	public abstract List<Transaction> getAllTransaction();
}
