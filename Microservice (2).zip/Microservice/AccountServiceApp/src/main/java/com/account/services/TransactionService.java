package com.account.services;

import java.util.List;

import com.account.models.Transaction;

public interface TransactionService {
	public abstract String createTransaction(Transaction transaction);

	public abstract String updateTransaction(Transaction transaction);

	public abstract String deleteTransaction(int tranId);

	public abstract Transaction getTransaction(int tranId);

	public abstract List<Transaction> getAllTransactionByAccNumber(long accNumber);

	public abstract List<Transaction> getAllTransaction();
}
