package com.account.services;

import java.util.List;

import com.account.exceptions.AccountNotFoundException;
import com.account.exceptions.NotEnoughBalanceException;
import com.account.models.Account;

public interface AccountService {
	
	public abstract boolean createAccount(Account account);
	public abstract boolean updateAccount(Account account);
	public abstract boolean deleteAccount(long accNumber);
	public abstract Account getAccount(long accNumber);
	
	public abstract boolean depositAccount(long accNumber, double amount) throws AccountNotFoundException;
	public abstract boolean withdrawAccount(long accNumber, double amount) throws NotEnoughBalanceException, AccountNotFoundException;
	public abstract boolean FundTransferAccount(long fromAccNumber, long toAccNumber, double amount) throws NotEnoughBalanceException, AccountNotFoundException;

	public abstract List<Account> getAccountList();
}
